package com.onlinepayment.spring_boot_soap_example.springbootsoapexample;

import com.onlinepayment.spring_boot_soap_example.springboot_soapexample.OnlinePaymentDetail;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Service
public class OnlinePaymentService {
    private static final Map<String, OnlinePaymentDetail> onlinePaymentDetail = new HashMap<>();
    private OnlinePaymentDetail onlinePaymentDetail;

    @PostConstruct
    public void intialize() {
        OnlinePaymentDetail detail = new OnlinePaymentDetail();
        detail.setRRN("RollNumber");
        detail.setBANK_CODE("BankDetail");
        detail.setCARDNUMBER(1234567);
        detail.setLANACCOUNT("Accountdetail");
        detail.setCUSTID(01);
        detail.setACTIVITYFLAG("Active");
        detail.setSTATUSRRN("Status");
        detail.setAMOUNT(2000);
        detail.setLASTPAYDATE(500);
        detail.setTRANSNUMBER("Transfer");
        detail.setREINSTATED("Reinstated");

        onlinePaymentDetail.put(detail.getRRN(), detail);
    }
    public OnlinePaymentDetail getOnlinePaymentDetails(String,OnlinePaymentDetail){
        Assert.notNull(onlinePaymentDetail,"The OnlinePaymentmust not be null");
        return OnlinePaymentDetail.get(onlinePaymentDetail);
    }

}

