package com.onlinepayment.spring_boot_soap_example.springbootsoapexample.service;

public class OnlinePaymentService {
    public int findOnlinePaymentDetail(int cardnumber) {
        return cardnumber;
    }
}
