@javax.xml.bind.annotation.XmlSchema(namespace = "http://onlinepayment.com/spring_boot_soap_example", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.onlinepayment.spring_boot_soap_example.springboot_soapexample;


