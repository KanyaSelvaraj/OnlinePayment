package com.onlinepayment.spring_boot_soap_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
